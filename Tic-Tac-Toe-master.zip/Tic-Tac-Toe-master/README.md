# Tic-Tac-Toe 
Online multiplayer tic tac toe game . Play with your friends now.

#Features
`<ul>
<li>Play Online</li>
<li>Create/Join Room</li>
<li>Upto 4 Players</li>
<li>Coin System</li>
<li>Coin to Paytm</li>
</ul>`

</br>

![App Preview Home screen](https://firebasestorage.googleapis.com/v0/b/stora-5c1e1.appspot.com/o/github%2FScreenshot%20(35).png?alt=media&token=b9835a69-1353-47ef-a8e4-3670540f3fb0)


</br>

![App Preview Home screen](https://firebasestorage.googleapis.com/v0/b/stora-5c1e1.appspot.com/o/github%2FScreenshot%20(31).png?alt=media&token=ba34a21e-055d-4767-8921-be044d72e622)

</br>

![App Preview Home screen](https://firebasestorage.googleapis.com/v0/b/stora-5c1e1.appspot.com/o/github%2FScreenshot%20(34).png?alt=media&token=c1ac4dc4-fb67-4e3a-83ab-4174688464b1)

</br>

![App Preview Home screen](https://firebasestorage.googleapis.com/v0/b/stora-5c1e1.appspot.com/o/github%2FScreenshot%20(31).png?alt=media&token=ba34a21e-055d-4767-8921-be044d72e622)

